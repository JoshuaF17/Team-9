
public class Match {
	private String dogBreed;
	private double matchScore = 0.0;
	
	// default constructor
	public Match() {
	}
	
	public Match(String dogBreed1, double matchScore1) {
		dogBreed = dogBreed1;
		matchScore = matchScore1;
	}
	
	public String getDogBreed() {
		return dogBreed;
	}
	
	public void setDogBreed(String dogBreed) {
		this.dogBreed = dogBreed;
	}
	
	public double getMatchScore() {
		return matchScore;
	}
	
	public void setMatchScore(double matchScore) {
		this.matchScore = matchScore;
	}

	public String toString() {
		return dogBreed + ": " + matchScore;
	}
	
	
}
