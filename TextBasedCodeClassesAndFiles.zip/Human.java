
public class Human extends DogBreed {
	/**
	 * 
	 */
	
	// instance variables
	private String name = "";
		
	public Human() {
		super();
	}

	/**
	 * @param t
	 * @param n
	 * @param f
	 * @param g
	 * @param h
	 * @param s
	 * @param b
	 */
	
	// constructors
	public Human(String breed, int t, int n, int f, int g, int h, int s, int b, int e) {
		super(breed, t, n, f, g, h, s, b, e);
		this.name = name;
	}
	
	public Human (String personName) {
		name = personName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		return "Profile:" + name + ", New Owner: " + getNewOwn() + ", Friendly: " + getFriendly() 
				+ ", Groom: " + getGroom() + ", Health: " + getHealth() + ", Size: " + getSize() 
				+ ", Train: " + getTrain() + ", Bark: " + getBark() + ", Exercise: " + getExercise();
	}
	
	
	
	
}
