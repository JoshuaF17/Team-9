public class DogBreed {

	// instance variables;
	private String breed = "";
	private double newOwn = 0;
	private double friendly = 0;
	private double groom = 0;
	private double health = 0;
	private double size = 0;
	private double train = 0;
	private double bark = 0;
	private double exercise = 0;
	
	// default constructor
	public DogBreed() {
	}
	
	// constructor with all variables in order to pair dog with potential candidates
	
	public DogBreed(String breed, double newOwn, double friendly, double groom, double health, double size, double train, double bark,
			double exercise) {
		this.breed = breed;
		this.newOwn = newOwn;
		this.friendly = friendly;
		this.groom = groom;
		this.health = health;
		this.size = size;
		this.train = train;
		this.bark = bark;
		this.exercise = exercise;
	}
	
	// getter/setter method


	public String getBreed() {
		return breed;
	}
	
	public void setBreed(String breedType) {
		breed = breedType;
	}
	
	public double getTrain(){
	   return train;   
	}
	
	public void setTrain(double train1){
	   train = train1;
	}
	public double getFriendly(){
	   return friendly;   
	}
	public void setFriendly(double friendly1){
	   friendly = friendly1;
	}
	public double getNewOwn(){
	   return newOwn;   
	}
	public void setNewOwn(double newOwn1){
	   newOwn = newOwn1;
	}
	public double getGroom(){
	   return groom;   
	}
	public void setGroom(double groom1){
	   groom = groom1;
	}
	public double getHealth(){
	   return health;   
	}
	public void setHealth(double health1){
	   health = health1;
	}
	public double getSize(){
	   return size;   
	}
	public void setSize(double size1){
	   size = size1;
	}
	public double getBark(){
	   return bark;   
	}
	public void setBark(double bark1){
	  bark = bark1;
	}
	
	public double getExercise() {
		return exercise;
	}
	
	public void setExercise(double exercise1) {
		exercise = exercise1;
	}

	
	public String toString() {
		return "Dog breed: " + breed + ", New Owner: " + newOwn + ", Friendly: " + friendly + ", Groom: " + groom
				+ ", Health: " + health + ", Size: " + size + ", Train: " + train + ", Bark: " + bark + ", Exercise: "
				+ exercise;
	}
	
	
	//main function
		
}