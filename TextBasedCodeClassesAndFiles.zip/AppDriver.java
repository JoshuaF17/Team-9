import java.io.IOException;

public class AppDriver {

	public static void main(String[] args) throws IOException {
		new DogTinder();
	}

}
