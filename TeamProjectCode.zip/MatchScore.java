import java.util.ArrayList;

// this object holds a score between the human and dog's compatibility
// 

public class MatchScore {
	//private String profileName; 
	private String matchedDogBreed;
	private double DHScore = 0.0;
	private String matchedImage;
	
	// default constructor
	public MatchScore() {}
	
	public MatchScore(String matchedDogBreed1, double DHScore1, String matchedImage1) {
		matchedDogBreed = matchedDogBreed1;
		DHScore = DHScore1;
		matchedImage = matchedImage1;
	}
	
	// creates match scores and adds the scores to the human's profile
	public ArrayList<MatchScore> createMatchScores(Human aHuman, Lists theLists) {
		
		ArrayList<DogBreed> listToCompare = theLists.listOfDogs;
		ArrayList<MatchScore> listOfMatchScores = new ArrayList<MatchScore>();
		
		for (DogBreed dog : listToCompare) {
			
			double matchScore = 0.0;
			double score = 0.0;

			score = Math.abs(aHuman.getNewOwn() - dog.getNewOwn());
			matchScore = matchScore + score;

			score = Math.abs(aHuman.getFriendly() - dog.getFriendly());
			matchScore = matchScore + score;

			score = Math.abs(aHuman.getGroom() - dog.getGroom());
			matchScore = matchScore + score;

			score = Math.abs(aHuman.getHealth() - dog.getHealth());
			matchScore = matchScore + score;

			score = Math.abs(aHuman.getTrain() - dog.getTrain());
			matchScore = matchScore + score;

			score = Math.abs(aHuman.getBark() - dog.getBark());
			matchScore = matchScore + score;

			score = Math.abs(aHuman.getExercise() - dog.getExercise());
			matchScore = matchScore + score;

			if (aHuman.getSize() != dog.getSize()) {
				matchScore = matchScore + 1;
			}
			// create an object matchScore
			MatchScore newMatchScore = new MatchScore(dog.getDog(), matchScore, dog.getImage());

			// add the created match score to the list
			listOfMatchScores.add(newMatchScore);
		}
		
		return listOfMatchScores;
	}
	
	public String getMatchedImage() {
		return matchedImage;
	}
	
	public String getMatchedDogBreed() {
		return matchedDogBreed;
	}
	
	public void setMatchedDogBreed(String matchedDogBreed) {
		this.matchedDogBreed = matchedDogBreed;
	}
	
	public double getDHScore() {
		return DHScore;
	}
	
	public void setDHScore(double DHScore) {
		this.DHScore = DHScore;
	}

	public String toString() {
		return matchedDogBreed + ": " + DHScore;
	}
	
}
