import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class SecondPage {
	protected Human currentH;
	
	public SecondPage() {}
	// constructor for SecondPage
	public SecondPage(Human aHuman) {
		currentH = aHuman;
	}
	
	public VBox getPage2Root(Human aHuman) {
		currentH = aHuman;
		
		TextField nameField = new TextField();
		VBox page2Root = new VBox(20);
		
		EventHandler<ActionEvent> nameEvent = new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				if (nameField != null) {
					currentH.setName(nameField.getText());
				}
			}
		};

		nameField.setOnAction(nameEvent);

		Label profileName = new Label("Name (press enter to confirm):");
		profileName.setFont(Font.font("Verdana", 15));

		Label ownerQ = new Label("Have you ever owned a dog before?");
		ownerQ.setFont(Font.font("Verdana", 20));

		// Create radio buttons for yes or no to new owner question
		RadioButton rbYes = new RadioButton();
		rbYes.setText("Yes");
		rbYes.setUserData("1");

		RadioButton rbNo = new RadioButton();
		rbNo.setText("No");
		rbNo.setUserData("0");

		ToggleGroup newToggleGroup = new ToggleGroup();

		rbYes.setToggleGroup(newToggleGroup);
		rbNo.setToggleGroup(newToggleGroup);

		// add listener to toggleGroup
		newToggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
				if (newToggleGroup != null) {
					if (newToggleGroup.getSelectedToggle().getUserData().toString() == "1") {
						currentH.setNewOwn(1);
					} 
					else if (newToggleGroup.getSelectedToggle().getUserData().toString() == "0") {
						currentH.setNewOwn(0);
				}
			}
			}
		});
		
		// button for third page
//		Button nextPgBtn = new Button("Continue to next page");
		
		// setting action for button 
//		nextPgBtn.setOnAction(e -> currentStage.setScene(sceneForPage3));
		
		// button to view the possible dogs
//		Button viewDogsBtn = new Button("View Possible Dogs");
//		viewDogsBtn.setFont(Font.font("Trajan", 25));
//		viewDogsBtn.setLayoutX(220);
//		viewDogsBtn.setLayoutY(0);
		
		// setting action for button
//		viewDogsBtn.setOnAction(e -> currentStage.setScene(sceneForPDogs));
		
		// adding all nodes to the root
//		page2Root.getChildren().add(viewDogsBtn);
//		page2Root.getChildren().add(nextPgBtn);
		page2Root.getChildren().add(profileName);
		page2Root.getChildren().add(nameField);
		page2Root.getChildren().add(ownerQ);
		page2Root.getChildren().add(rbYes);
		page2Root.getChildren().add(rbNo);
		
		// aligning the root
		page2Root.setAlignment(Pos.CENTER);
		
//		Scene page2Scene = new Scene(page2Root, 450, 700);
//		Stage primaryStage = new Stage();
//		primaryStage.setScene(secondScene);
		
		// return the scene
		return page2Root;
	}
	
	public Button getPg2DogsBtn() {
		Button viewDogsBtn = new Button("View Possible Dogs");
		viewDogsBtn.setFont(Font.font("Trajan", 25));
		viewDogsBtn.setLayoutX(220);
		viewDogsBtn.setLayoutY(0);
		
		return viewDogsBtn;
	}

	public Button getPg2ContinueBtn() {
		Button nextPgBtn = new Button("Continue to next page");
		return nextPgBtn;
	}

}
