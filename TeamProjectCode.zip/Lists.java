import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Lists {
	protected ArrayList<DogBreed> listOfDogs = new ArrayList<DogBreed>();
	protected ArrayList<String> listOfQuestions = new ArrayList<String>();
	protected ArrayList<String> dogNames = new ArrayList<String>();
	// protected ArrayList<HumanProfile> listOfHumans = new ArrayList<HumanProfile>();
	
	
	// default constructor
	public Lists() {}
	
	// method that loads dogs from a data set
	public void loadDogs(String dataset) throws IOException {

		BufferedReader fileReader = new BufferedReader(new FileReader(dataset));
		String line = fileReader.readLine();
		while (line != null) {

			String[] fields = line.split(",");

			listOfDogs.add(new DogBreed(fields[0], Double.parseDouble(fields[1]), Double.parseDouble(fields[2]),
					Double.parseDouble(fields[3]), Double.parseDouble(fields[4]), Double.parseDouble(fields[5]),
					Double.parseDouble(fields[6]), Double.parseDouble(fields[7]), Double.parseDouble(fields[8]), 
					fields[9]));
			
			line = fileReader.readLine();

		}
		fileReader.close();
	} 
	

	public void loadDogNames() throws IOException {
		
		BufferedReader fileReader = new BufferedReader(new FileReader("dogNames.txt"));
		String line = fileReader.readLine();
		while (line != null) {
			dogNames.add(line);
			line = fileReader.readLine();
		}
		fileReader.close();
	}
	

	
	// takes filename and retrieves it from the SAME folder
	// loads all the questions into an array list that can be used to call later
	public void loadQuestions(String fileName) throws IOException {
		BufferedReader fileR = new BufferedReader(new FileReader(fileName));
		String line = fileR.readLine();
		while (line != null) {
			listOfQuestions.add(line);
			line = fileR.readLine();
		}
		fileR.close();
	}
	
	public void printQuestions() {
		for (int i = 0; i < listOfQuestions.size(); i++) {
			System.out.println(listOfQuestions.get(i));
		}
	}
	
	public void printDogs() {
		for (DogBreed dog : listOfDogs) {
			System.out.println(dog);
		}
	}
	
	
	
}
