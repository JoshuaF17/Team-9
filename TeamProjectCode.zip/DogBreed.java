
public class DogBreed extends Traits {
		private String dog;
		private String imgName; 
		// default constructor
		public DogBreed() {};
		
		
		// constructor
		
		public DogBreed(String aDog, double newOwn, double friendly, double groom, double health, double size, double train, double bark,
			double exercise, String img) {
			super(newOwn, friendly, groom, health, size, train, bark, exercise);
			this.dog = aDog;
			this.imgName = img;
		}
		
		// copy constructor 
		public DogBreed(DogBreed aDogBreed) {
			super(aDogBreed);
			dog = aDogBreed.dog;
		}
		
		public String getImage() {
			return imgName;
		}
		
		public void setDog(String aDogBreed) {
			dog = aDogBreed;
		}
		
		public String getDog() {
			return dog;
		}
		
		public String toString() {
			return "Traits of the dog: " + dog + super.toString();
		}
}
