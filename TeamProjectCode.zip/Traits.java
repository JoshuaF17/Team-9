// create super class of traits 
public class Traits {

	// instance variables;

	protected double newOwn = 0;
	protected double friendly = 0;
	protected double groom = 0;
	protected double health = 0;
	protected double size = 0;
	protected double train = 0;
	protected double bark = 0;
	protected double exercise = 0;
	

	// default constructor
	public Traits() {}
	
	public Traits(double newOwn, double friendly, double groom, double health, double size, double train, double bark,
			double exercise) {
		this.newOwn = newOwn;
		this.friendly = friendly;
		this.groom = groom;
		this.health = health;
		this.size = size;
		this.train = train;
		this.bark = bark;
		this.exercise = exercise;
	}
	
	// copy constructor
	public Traits(Traits newTraits) {
		this.newOwn = newTraits.newOwn;
		this.friendly = newTraits.friendly;
		this.groom = newTraits.groom;
		this.health = newTraits.health;
		this.size = newTraits.size;
		this.train = newTraits.train;
		this.bark = newTraits.bark;
		this.exercise = newTraits.exercise;
		
	}
	
	public double getTrain(){
	   return train;   
	}
	
	public void setTrain(double train1){
	   train = train1;
	}
	public double getFriendly(){
	   return friendly;   
	}
	public void setFriendly(double friendly1){
	   friendly = friendly1;
	}
	public double getNewOwn(){
	   return newOwn;   
	}
	public void setNewOwn(double newOwn1){
	   newOwn = newOwn1;
	}
	public double getGroom(){
	   return groom;   
	}
	public void setGroom(double groom1){
	   groom = groom1;
	}
	public double getHealth(){
	   return health;   
	}
	public void setHealth(double health1){
	   health = health1;
	}
	public double getSize(){
	   return size;   
	}
	public void setSize(double size1){
	   size = size1;
	}
	public double getBark(){
	   return bark;   
	}
	public void setBark(double bark1){
	  bark = bark1;
	}
	
	public double getExercise() {
		return exercise;
	}
	
	public void setExercise(double exercise1) {
		exercise = exercise1;
	}

	public String toString() {
		
		return " | New Owner: " + newOwn + ", Friendly: " + friendly + ", Groom: " + groom
				+ ", Health: " + health + ", Size: " + size + ", Train: " + train + ", Bark: " + bark + ", Exercise: "
				+ exercise;
	}
	
}
