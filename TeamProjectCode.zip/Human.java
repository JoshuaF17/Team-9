
import java.util.ArrayList;

public class Human extends Traits {
	// variable to hold the Human's name, human's best dog match and the image of the best dog match
	protected String name;
	
	// protected HumanDogMatches matches;
	protected String perfectDogMatch = "No dog matched";
	protected String secondDogMatch = "No dog matched";
	protected String thirdDogMatch = "No dog matched";
	protected String pDogImage = "file:defaultimage.png";
	protected String dog2Image = "file:defaultimage.png";
	protected String dog3Image = "file:defaultimage.png";
	protected double perfectDogMatchScore = 26.0;
	protected double secondDogMatchScore = 26.0;
	protected double thirdDogMatchScore = 26.0;
	
	// list to hold all the MatchScore the human has with the dog
	protected ArrayList<MatchScore> matchScores = new ArrayList<MatchScore>();
	
	
	
	// default constructor
	public Human() {}
	
	// constructor for just a name
	public Human(String aName) {
		name = aName;
	}
	
	// constructor for name and all traits
	public Human(String aName, double newOwn, double friendly, double groom, double health, double size, double train, double bark,
			double exercise) {
		super(newOwn, friendly, groom, health, size, train, bark, exercise);
		this.name = aName;
	}
	
	// copy constructor 
	public Human(Human aProfile) {
		super(aProfile);
		name = aProfile.name;
	}
	
	public void setName(String aName) {
		name = aName;
	}
	
	public String getName() {
		return name;
	}
	
	public void setListOfMatchScores(ArrayList<MatchScore> aList) {
		matchScores = aList;
	}

//	public ArrayList<MatchScore> getMatchScores() {
//		return matchScores;
//	}
//	
	public void createMatchScores(Lists theLists) {
		
		ArrayList<DogBreed> listToCompare = theLists.listOfDogs;
		ArrayList<MatchScore> listOfMatchScores = new ArrayList<MatchScore>();
		
		for (DogBreed dog : listToCompare) {
			
			double matchScore = 0.0;
			double score = 0.0;

			score = Math.abs(this.newOwn - dog.getNewOwn());
			matchScore = matchScore + score;

			score = Math.abs(this.friendly - dog.getFriendly());
			matchScore = matchScore + score;

			score = Math.abs(this.groom - dog.getGroom());
			matchScore = matchScore + score;

			score = Math.abs(this.health - dog.getHealth());
			matchScore = matchScore + score;

			score = Math.abs(this.train - dog.getTrain());
			matchScore = matchScore + score;

			score = Math.abs(this.bark - dog.getBark());
			matchScore = matchScore + score;

			score = Math.abs(this.exercise - dog.getExercise());
			matchScore = matchScore + score;

			if (this.getSize() != dog.getSize()) {
				matchScore = matchScore + 1;
			}
			// create an object matchScore
			MatchScore newMatchScore = new MatchScore(dog.getDog(), matchScore, dog.getImage());
			
			// add the created match score to the list
			listOfMatchScores.add(newMatchScore);
		}
		
		matchScores = listOfMatchScores;
	}
	
	public String getPerfectMatch() {
		double bestMatchScore = 26.0;
		for (MatchScore i : matchScores) {
			if (i.getDHScore() < bestMatchScore) {
				bestMatchScore = i.getDHScore();
				perfectDogMatch = i.getMatchedDogBreed();
			}
		}
		return perfectDogMatch;
	}
	
	public String getPerfectMatchImage() {
		double bestMatchScore = 26.0;
		for (MatchScore i : matchScores) {
			if (i.getDHScore() < bestMatchScore) {
				bestMatchScore = i.getDHScore();
				perfectDogMatch = i.getMatchedDogBreed();
				pDogImage = i.getMatchedImage();
				perfectDogMatchScore = i.getDHScore();
			}
		}
		return "file:" + pDogImage;
	}
	
	public String getSecondMatch() {
		for (MatchScore i: matchScores) {
			if (i.getDHScore() >= perfectDogMatchScore && i.getDHScore() <= secondDogMatchScore) {
				secondDogMatchScore = i.getDHScore();
				secondDogMatch = i.getMatchedDogBreed();
				dog2Image = i.getMatchedImage();
			}
		}
		return secondDogMatch;
	}
	
	public String getdog2Image() {
		for (MatchScore i : matchScores) {
			if (i.getDHScore() >= perfectDogMatchScore && i.getDHScore() <= secondDogMatchScore) {
				secondDogMatchScore = i.getDHScore();
				secondDogMatch = i.getMatchedDogBreed();
				dog2Image = i.getMatchedImage();
			}
		}
		return dog2Image;
	}	
	
	public String getThirdMatch() {
		for (MatchScore i: matchScores) {
			if (i.getDHScore() >= perfectDogMatchScore && i.getDHScore() < thirdDogMatchScore) {
				thirdDogMatchScore = i.getDHScore();
				thirdDogMatch = i.getMatchedDogBreed();
				dog3Image = i.getMatchedImage();
			}
		}
		return thirdDogMatch;
	}
	
	public String getdog3Image() {
		for (MatchScore i : matchScores) {
			if (i.getDHScore() >= perfectDogMatchScore && i.getDHScore() < thirdDogMatchScore) {
				thirdDogMatchScore = i.getDHScore();
				secondDogMatch = i.getMatchedDogBreed();
				dog2Image = i.getMatchedImage();
			}
		}
		return dog3Image;
	}
	
	public String toString() {
		return "Traits of the human: " + name + super.toString();
	}
	
	
	
}
